export const login = (user) => ({
  type: 'LOGIN',
  payload: user,
});
